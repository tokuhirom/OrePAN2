package gaaa::foo;
use strict;
use warnings;
use utf8;



1;

