# NAME

Acme::Foo - It's new $module

# SYNOPSIS

    use Acme::Foo;

# DESCRIPTION

Acme::Foo is ...

# LICENSE

Copyright (C) tokuhirom.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

tokuhirom <tokuhirom@gmail.com>
